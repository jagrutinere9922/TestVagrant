package Ipl;
import java.util.*;
public class IplTeam {
	// As per 1st requirement data structure is created
	String name;
	int points;
	String last5;
	
	IplTeam(String tname,int tpoints, String tlast5)
	{
		name=tname;
		points=tpoints;
		last5=tlast5;
	}
	
	public static void main(String[] args) {
		
		ArrayList<IplTeam> al=new ArrayList<>();
		
		Scanner sc = new Scanner(System.in) ;
		 
		al.add( new IplTeam("GT",20,"WWLLW") );
		al.add( new IplTeam("LGS",18,"WLLWW") );
		al.add( new IplTeam("RR",16,"WLWLL") );
		al.add( new IplTeam("DC",14,"WWLWL") );
		al.add( new IplTeam("RCB",14,"LWWLL") );
		al.add( new IplTeam("KKR",12,"LWWLW") );
		al.add( new IplTeam("PBKS",12,"LWLWL") );
		al.add( new IplTeam("SRH",12,"WLLLL") );
		al.add( new IplTeam("CSK",8,"LLWLW") );
		al.add( new IplTeam("MI",6,"LWLWW") );
		int sum=0, count=0;
		int nLoss=0;
		String cmp="";
		
		//As per 2nd requirement Teams with 2 continuous losses
		
		System.out.println("Team with 2 continuous losses :");
		for(IplTeam t:al)
		{
			if(t.last5.contains("LL"))
			{
				System.out.println(" "+t.name+" "+t.points+" "+t.last5);
			}
		}
		
	   try {	
		   		//As per 3rd requirement teams with n consecutive losses/wins
		   
		   		System.out.println("Whether you want to check Win Or Loss??"+"\n"+"W or L :");
		   		char choice=sc.next().charAt(0);
		   		if(choice=='L'||choice=='l')
		   		{
		   			System.out.println(" Enter the number of losses you want to check in team ");
		   			nLoss =sc.nextInt();
		
		   			for(int i=0;i<nLoss;i++)
		   			{
		   				cmp=cmp+"L";
		   			}
		   			
		
		   			for(IplTeam t:al)
		   			{
		   				if(t.last5.contains(cmp))
		   				{
		   					System.out.println(" "+t.name+" "+t.points+" "+t.last5);
		   					count++;
		   					sum=sum+t.points;
		   				}
		   			}
		   			double avg1=sum/count;
		   			System.out.println("Average of team with "+nLoss+" continuous losses is "+avg1);
		
		   		}
		   		else if(choice=='W'|| choice=='w')
		   		{
		   			System.out.println(" Enter the number of Wins you want to check in team ");
		   			int nWin =sc.nextInt();
		
		   			for(int i=0;i<nWin;i++)
		   			{
		   				cmp=cmp+"W";
		   			}
		   		
		
		   			for(IplTeam t:al)
		   			{
		   				if(t.last5.contains(cmp))
		   				{
		   					System.out.println(" "+t.name+" "+t.points+" "+t.last5);
		   					count++;
		   					sum=sum+t.points;
		   				}
		   			}
		   			//as per 4th requirement average points of filter teams 
		   			
		   			double avg=sum/count;
		   			System.out.println("Average of team with "+nWin+" continuous wins is "+avg);
		   		}
	   }
	   catch(Exception e)
	   {
		   System.out.println("Team is not having this number of  continuous losses or wins ..please enter valid number..");
	   }
		
			
	}
}